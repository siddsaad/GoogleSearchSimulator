
public class Links {
	
	private int id;
	private String name;
	
	public Links(int i, String n){
		this.id=i;
		this.name=n;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
}